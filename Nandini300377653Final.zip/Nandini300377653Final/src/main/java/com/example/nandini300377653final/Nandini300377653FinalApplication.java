package com.example.nandini300377653final;

import com.example.nandini300377653final.entities.Student;
import com.example.nandini300377653final.repositories.StudentRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class Nandini300377653FinalApplication {

    public static void main(String[] args) {
        SpringApplication.run(Nandini300377653FinalApplication.class, args);
    }
    @Bean
    CommandLineRunner run(StudentRepository studentRepository) {
        return args -> {
            // Inserting sample data
            studentRepository.save(new Student(1L, "Nandini", "CSIS 3275", 3, "A"));


            System.out.println("Sample rentals inserted into the database!");
        };
    }

}
