/*package com.example.nandini300377653final.controller;


import ch.qos.logback.core.model.Model;
import com.example.nandini300377653final.entities.Student;
import com.example.nandini300377653final.repositories.StudentRepository;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


import java.util.List;

@Controller
@AllArgsConstructor
@NoArgsConstructor
public class StudentController {
    @Autowired
     private StudentRepository studentRepository;

    @GetMapping(path = "/index")
    public String rentals(Model model, @RequestParam(name = "keyword", defaultValue = "") String keyword) {
        List<Student> students;
        if (keyword.isEmpty()) {
            students = studentRepository.findAll();
        } else {
            Long key = Long.parseLong(keyword);
            students = studentRepository.findStudentByStudentNumber(key);
        }
        model.addAttribute("listRentals", students);
        return "student";
    }

}*/
package com.example.nandini300377653final.controller;

import com.example.nandini300377653final.entities.Student;
import com.example.nandini300377653final.repositories.StudentRepository;
import jakarta.servlet.http.HttpSession;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Controller
@AllArgsConstructor
@NoArgsConstructor
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;
    static int num = 0; // Static variable to track save mode (add or edit)

    @GetMapping(path = "/index")
    public String students(Model model, @RequestParam(name = "keyword", defaultValue = "") String keyword) {
        List<Student> students;
        if (keyword.isEmpty()) {
            students = studentRepository.findAll();
        } else {
            Long key = Long.parseLong(keyword);
            students = studentRepository.findStudentByStudentNumber(key);
        }
        model.addAttribute("listStudents", students);

        return "student";
    }

    @GetMapping("/delete")
    public String delete(Long id) {
        studentRepository.deleteById(id);
        return "redirect:/index";
    }
    @GetMapping("/formAdd")
    public String formStudent(Model model) {
        model.addAttribute("student", new Student());
        return "add";
    }

    @PostMapping(path = "/save")
    public String save(Model model, Student student, BindingResult bindingResult, ModelMap mm, HttpSession session) {
        if (bindingResult.hasErrors()) {
            return "add";
        }
        if (studentRepository.existsById(student.getStudentNumber())) {
            bindingResult.rejectValue("studentNumber", "error.studentNumber", "Student ID already exists.");
            return "add";
        }

        studentRepository.save(student);
        if (num == 2) {
            mm.put("e", 2);
            mm.put("a", 0);
        } else {
            mm.put("a", 1);
            mm.put("e", 0);
        }
        return "redirect:/index";
    }

    @GetMapping("/edit")
    public String editStudents(Model model, Long id, HttpSession session){
        num = 2;
        session.setAttribute("info", 0);
        Student student = studentRepository.findById(id).orElse(null); if(student==null) throw new RuntimeException("ID does not exist"); model.addAttribute("student", student);
        return "edit";
    }

    @PostMapping(path = "/update")
    public String update(Model model, Student student, BindingResult bindingResult, ModelMap mm, HttpSession session) {
        if (bindingResult.hasErrors()) {
            return "edit";
        }

        studentRepository.save(student);
        if (num == 2) {
            mm.put("e", 2);
            mm.put("a", 0);
        } else {
            mm.put("a", 1);
            mm.put("e", 0);
        }
        return "redirect:/index";
    }

    @GetMapping("/formGPA")
    public String calculateCost(@RequestParam Long id, Model model) {
        Student student = studentRepository.findById(id).orElseThrow(() -> new RuntimeException("Rental not found"));

        double pointValue ; //
        String grade= student.getGrade();

        List<Student> students;
       students= studentRepository.findAll();
       double gpa;
       int unit=student.getUnits();
       for (Student s : students) {
           if(grade.equalsIgnoreCase("a"))
               pointValue=4;
           else if (grade.equalsIgnoreCase("b"))
               pointValue=3;
           else if (grade.equalsIgnoreCase("c"))
               pointValue=2;
           else if (grade.equalsIgnoreCase("d"))
               pointValue=1;
           else
               pointValue=0;
           gpa= pointValue/unit;
       }

        Map<Integer, Double> projections = new LinkedHashMap<>();


        for (Student s : students) {
            if(grade.equalsIgnoreCase("a"))
                pointValue=4;
            else if (grade.equalsIgnoreCase("b"))
                pointValue=3;
            else if (grade.equalsIgnoreCase("c"))
                pointValue=2;
            else if (grade.equalsIgnoreCase("d"))
                pointValue=1;
            else
                pointValue=0;
            gpa= pointValue/unit;
        }

        model.addAttribute("student", student);
        model.addAttribute("projections", projections);

        return "gpa";
    }
}
