package com.example.nandini300377653final.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Entity
@Data
public class Student {
    @Id
    private Long studentNumber;
    private String studentName;
    private String courseName;
    private int units;
    private String grade;

    public Student(Long studentNumber, String studentName, String courseName, int units, String grade) {
        this.studentNumber = studentNumber;
        this.studentName = studentName;
        this.courseName = courseName;
        this.units = units;
        this.grade = grade;
    }
    public Student() {}
}
