package com.example.nandini300377653final.repositories;

import com.example.nandini300377653final.entities.Student;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface StudentRepository extends JpaRepository<Student,Long> {
    List<Student> findStudentByStudentNumber(Long kw);
}
