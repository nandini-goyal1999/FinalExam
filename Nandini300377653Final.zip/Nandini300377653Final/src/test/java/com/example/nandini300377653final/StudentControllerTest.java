package com.example.nandini300377653final;





import com.example.nandini300377653final.controller.StudentController;
import com.example.nandini300377653final.entities.Student;
import com.example.nandini300377653final.repositories.StudentRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import jakarta.servlet.http.HttpSession;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class StudentControllerTest {

    @InjectMocks
    private StudentController studentController;

    @Mock
    private StudentRepository studentRepository;

    @Mock
    private Model model;

    @Mock
    private ModelMap modelMap;

    @Mock
    private BindingResult bindingResult;

    @Mock
    private HttpSession session;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testSaveRentalSuccessfully() {
        try {
            Student student = new Student(1L, "Joe", "csis 3275", 3, "A");
            when(bindingResult.hasErrors()).thenReturn(false);

            String result = studentController.save(model, student, bindingResult, modelMap, session);

            verify(studentRepository, times(1)).save(student);
            assertEquals("redirect:/index", result);
            System.out.println("testSaveRentalSuccessfully: PASS");
        } catch (AssertionError | Exception e) {
            System.out.println("testSaveRentalSuccessfully: FAIL - " + e.getMessage());
        }
    }

    @Test
    void testDeleteRental() {
        try {
            // Arrange: Mock rental ID
            Long rentalId = 1L;

            // Act: Call the delete method
            String result = studentController.delete(rentalId);

            // Assert: Verify that deleteById was called once with the correct ID
            verify(studentRepository, times(1)).deleteById(rentalId);

            // Assert: Ensure the correct redirect URL is returned
            assertEquals("redirect:/index", result);

            // Print Pass Message
            System.out.println("testDeleteRental: PASS");
        } catch (AssertionError | Exception e) {
            // Print Fail Message
            System.out.println("testDeleteRental: FAIL - " + e.getMessage());
        }
    }

    @Test
    void testSaveRentalValidationError() {
        try {
            Student student = new Student();
            when(bindingResult.hasErrors()).thenReturn(true);

            String result = studentController.save(model, student, bindingResult, modelMap, session);

            verify(studentRepository, never()).save(any());
            assertEquals("formRentals", result);
            System.out.println("testSaveRentalValidationError: PASS");
        } catch (AssertionError | Exception e) {
            System.out.println("testSaveRentalValidationError: FAIL - " + e.getMessage());
        }
    }




}


