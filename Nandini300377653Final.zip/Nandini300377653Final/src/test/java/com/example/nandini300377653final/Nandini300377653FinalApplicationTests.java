package com.example.nandini300377653final;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Nandini300377653FinalApplicationTests {

    @Test
    void contextLoads() {
    }

}
